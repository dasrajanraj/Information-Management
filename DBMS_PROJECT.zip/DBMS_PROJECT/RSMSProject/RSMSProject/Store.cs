﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class Store : Form
    {
        public Store()
        {
            InitializeComponent();
        }
        public int i;
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery = "";
            sqlquery = @"INSERT INTO [dbo].[store]
           ([storeid]
           ,[streetname]
           ,[city]
           ,[zip]
           ,[Contact])
     VALUES
           ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')";
            SqlCommand cmd = new SqlCommand(sqlquery, con);
            try
            {
                i = cmd.ExecuteNonQuery();

            }
            catch
            {

            }
            finally
            {
                if (i > 0)
                {
                    MessageBox.Show("Item Inserted SuccessFully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Item Not Inserted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                loadData();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery = @"UPDATE store SET streetname = '" + textBox2.Text + "',city = '" + textBox3.Text + "',[zip] = '" + textBox4.Text + "',[Contact] = '" + textBox5.Text + "' WHERE [storeid] = '" + textBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(sqlquery, con);
            try
            {
                i = cmd.ExecuteNonQuery();

            }
            catch
            {

            }
            finally
            {
                if (i > 0)
                {
                    MessageBox.Show("Item Inserted SuccessFully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Item Not Inserted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                loadData();
            }
        }
        public void loadData()
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM store", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["storeid"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["streetname"].ToString();             
                dataGridView1.Rows[n].Cells[2].Value = item["city"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["zip"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["contact"].ToString();
            }
            con.Close();
        }

        private void Store_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}