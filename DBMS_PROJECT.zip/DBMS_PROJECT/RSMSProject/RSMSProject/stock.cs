﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class stock : Form
    {
        public stock()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            addstock ads = new addstock();
            ads.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            viewstock vws = new viewstock();
            vws.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_Stock udtst = new Update_Stock();
            udtst.Show();
        }
        public void loadData()
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select a.[productcode],[productname],[transdate],[purchased_quantity],[price] from stock a right outer join Products b on a.[productcode]=b.productcode  and b.[productcode] IS NOT NULL;", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["productcode"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["productname"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["transdate"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["purchased_quantity"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["price"].ToString();
            }
            con.Close();
        }
        private void stock_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
