﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class Product : Form
    {
        public static int i;
        public Product()
        {
            InitializeComponent();
        }
        private void Product_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            loadData();
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            bool status = false;
            if (comboBox1.SelectedIndex == 0)
            {
                status = true;
            }
            else
            {
                status=false;
            }

            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery = "";
            if (ifproductexist(con,textBox1.Text)) {
                sqlquery = @"UPDATE [Products] SET [productname] = '" + textBox2.Text + "',[productstatus] = '" + status + "',[price]='"+textBox3.Text+"' where [productcode] = '" + textBox1.Text + "'";
            }
            else
            {
                sqlquery = @"INSERT INTO[dbo].[Products]
                            ([productcode]
                             ,[productname]
                            ,[productstatus],
                              [price]  )
                            VALUES
                            ('" + textBox1.Text + "','" + textBox2.Text + "','" + status + "','"+textBox3.Text+"')";
            }
            SqlCommand cmd = new SqlCommand(sqlquery,con);
            try
            {
                i = cmd.ExecuteNonQuery();

            }
            catch
            {
           
            }
            finally
            {
                if (i > 0)
                {
                    MessageBox.Show("Item Inserted SuccessFully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    comboBox1.Text = "";
                    textBox3.Text = "";
                }
                else
                {
                    MessageBox.Show("Item Not Inserted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                loadData();
            }
        }
        public void loadData()
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [dbo].[Products]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach(DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["productcode"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["productname"].ToString();

                if ((bool)item["productstatus"])
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Availiable";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Out of Stock";
                }
                dataGridView1.Rows[n].Cells[3].Value = item["price"].ToString();
            }
            con.Close();
        }
        private void DataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            if (dataGridView1.SelectedRows[0].Cells[2].Value.ToString() == "Availiable")
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.SelectedIndex = 1;
            }
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
        }
        private bool ifproductexist(SqlConnection con,string productcode)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Products Where [productcode]='" + productcode + "'", con);
            DataTable tb = new DataTable();
            sda.Fill(tb);
            if (tb.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM [dbo].[Products] WHERE [productcode]='" + textBox1.Text + "'", con);
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
            {
                MessageBox.Show("Item Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Item NOT Deleted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
            loadData();
        }
    }
}
