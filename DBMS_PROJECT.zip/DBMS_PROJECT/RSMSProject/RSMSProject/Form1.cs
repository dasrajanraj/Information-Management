﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace RSMSProject
{
      public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("Select username,pword FROM login Where username='" + username.Text + "' and pword='" + password.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            
            con.Open();
            sda.Fill(dt);
            if(dt.Rows.Count == 1)
            {
                this.Hide();
                RetailStoreManagementSystem main = new RetailStoreManagementSystem();
                main.Show();
            }
            else
            {
                MessageBox.Show("invalid Username And Password...");
                button2_Click(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            username.Text = "";
            password.Clear();
            username.Focus();
        }
    }
}
