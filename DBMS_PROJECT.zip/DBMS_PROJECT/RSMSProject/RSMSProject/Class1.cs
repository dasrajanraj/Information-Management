﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSMSProject
{
    class Class1 //insert customer class
    {
       
        public string customerid{ get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string addr { get; set; }
        public int amt_paid { get; set; }
        public int amt_due { get; set; }
        public string contact { get; set; }

    }
    
}
