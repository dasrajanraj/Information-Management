﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        public int i;

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery = "";
            if (ifempexist(con, textBox1.Text))
            {
                sqlquery = @"UPDATE [dbo].[employee]
                            SET [fname] = '" + textBox2.Text + "',[lname] = '" + textBox3.Text + "',[designation] = '" + textBox4.Text + "',[doj] = '" + dateTimePicker1.Text + "',[salary] = '" + textBox6.Text + "',[contact] = '" + textBox7.Text + "',[storeid]'" + textBox5.Text + "' WHERE [ssn]='" + textBox1.Text + "' ";
            }
            else
            {
                sqlquery = @"INSERT INTO [dbo].[employee]
                            ([ssn]
                            ,[fname]
                            ,[lname]
                            ,[designation]
                            ,[doj]
                            ,[salary]
                            ,[contact]
                            ,[storeid])
                        VALUES
                        ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + dateTimePicker1.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox5.Text + "')";
            }
            SqlCommand cmd = new SqlCommand(sqlquery, con);
            try
            {
                i = cmd.ExecuteNonQuery();

            }
            catch
            {

            }
            finally
            {
                if (i > 0)
                {
                    MessageBox.Show("Item Inserted SuccessFully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                }
                else
                {
                    MessageBox.Show("Item Not Inserted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                loadData();
            }
        }
        private bool ifempexist(SqlConnection con, string empid)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM[dbo].[employee] WHERE [ssn]='" + empid + "'", con);
            DataTable tb = new DataTable();
            sda.Fill(tb);
            if (tb.Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void loadData()
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select * FROM [dbo].[Employee]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ssn"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["fname"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["lname"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = item["designation"].ToString();
                dataGridView1.Rows[n].Cells[4].Value = item["doj"].ToString();
                dataGridView1.Rows[n].Cells[5].Value = item["salary"].ToString();
                dataGridView1.Rows[n].Cells[6].Value = item["contact"].ToString();
                dataGridView1.Rows[n].Cells[7].Value = item["storeid"].ToString();


            }
            con.Close();
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            dateTimePicker1.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            textBox6.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            textBox7.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("DELETE FROM [dbo].[employee] WHERE [ssn]='" + textBox1.Text + "'", con);
            int j = cmd.ExecuteNonQuery();
            if (j > 0)
            {
                MessageBox.Show("Item Deleted Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Item NOT Deleted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
            loadData();
        }

    }
}