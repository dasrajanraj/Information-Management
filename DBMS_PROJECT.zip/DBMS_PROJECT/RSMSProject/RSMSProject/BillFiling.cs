﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class BillFiling : Form
    {
        public BillFiling()
        {
            InitializeComponent();
        }
        public int i,j;
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery1 = "";
            sqlquery1 = @"INSERT INTO bill
           ([billid]
           ,[customerid]
           ,[bil_amt])
     VALUES

        ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "')";

            string sqlquery2 = @"UPDATE customer SET amt_due = amt_due + " + textBox3.Text + " where customerid='" + textBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(sqlquery1, con);
            SqlCommand cmd1 = new SqlCommand(sqlquery2, con);
            try
            {
                i = cmd.ExecuteNonQuery();
                j = cmd1.ExecuteNonQuery();
            }
            catch
            {

            }
            finally { 
           
                if (i > 0 && j>0)
                {
                    MessageBox.Show("BILL  Filed SuccessFully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Bill Not Filed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Customer cus = new Customer();
            cus.Show();
        }
    }
}
