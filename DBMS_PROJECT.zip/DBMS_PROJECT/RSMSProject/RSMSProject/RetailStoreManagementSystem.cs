﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSMSProject
{
    public partial class RetailStoreManagementSystem : Form
    {

        public RetailStoreManagementSystem()
        {
            InitializeComponent();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product prod = new Product();
            prod.MdiParent = this;
            prod.Show();
        }

        

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            stock sto = new stock();
            sto.MdiParent = this;
            sto.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.MdiParent = this;
            emp.Show();
        }

        private void supplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            supplier sup = new supplier();
            sup.MdiParent = this;
            sup.Show();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer cus = new Customer();
            cus.MdiParent = this;
            cus.Show();
        }

        private void storeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Store sto = new Store();
            sto.MdiParent = this;
            sto.Show();
        }

        private void billRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BillFiling bilf = new BillFiling();
            bilf.MdiParent = this;
            bilf.Show();
        }
    }
}
