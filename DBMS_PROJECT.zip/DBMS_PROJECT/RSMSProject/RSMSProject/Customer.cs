﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace RSMSProject
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
        public int i;
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            createnewCustomer crn = new createnewCustomer();
            crn.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string sqlquery = "";
            SqlCommand cmd;
            int amt_paid = Convert.ToInt32(textBox7.Text);
            sqlquery = @"UPDATE customer SET amt_paid = amt_paid +" + amt_paid + "   where customerid='" + textBox1.Text + "' and [firstname]='" + textBox2.Text + "'; UPDATE customer SET amt_due=amt_due-" + amt_paid + " where customerid='" + textBox1.Text + "' and firstname='" + textBox2.Text + "'";

            cmd = new SqlCommand(sqlquery, con);
            try
            {
                i = cmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                if (i > 0)
                {
                    MessageBox.Show("SuccessFully paid", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox7.Text = "";
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Payment Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
            }
        }
       

        private void button3_Click(object sender, EventArgs e)
        {
            /*
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT SUM(purchased_quantity) FROM[dbo].[stock] WHERE [productcode]='" + textBox1.Text + "'", con);
            DataTable db = new DataTable();
            sda.Fill(db);
            string total = db.Rows[0][0].ToString();
            MessageBox.Show("The Total Quantity in Stock is" + " " + total);

            */
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-AD31VV6A;Initial Catalog=RSMSDatabase;Integrated Security=True");
            con.Open();
            string amt = "";
            SqlDataAdapter sda = new SqlDataAdapter("SELECT amt_due FROM customer where customerid = '" + textBox3.Text + "' and firstname='"+textBox6.Text+"'", con);
            DataTable tb = new DataTable();
            sda.Fill(tb);

            if (tb!=null)
            {
                amt = tb.Rows[0][0].ToString();
                MessageBox.Show("The DUE amount is " + " " + amt);
            }
            else
            {
                MessageBox.Show("Incorrect Name OR Customer Id\n");
                textBox4.Text = "";
                textBox5.Text = "";
                textBox4.Focus();
            }
            /*try {
            
                amt = tb[0].ToString();
                MessageBox.Show("The DUE amount is " + " " + amt);

            }
            catch
            {
                MessageBox.Show("Incorrect Name OR Customer Id\n");
                textBox4.Text = "";
                textBox5.Text = "";
            }
            finally
            {
                textBox4.Focus();
            }*/
            con.Close();
        }
    }
}
